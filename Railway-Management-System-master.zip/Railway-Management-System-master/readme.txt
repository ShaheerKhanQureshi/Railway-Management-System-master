***************************RAILWAY MANAGEMENT SYSTEM************************

DATASTRUCTURE USED:
-------------------------------
1) LinkedLIST
2) ARRAYLIST

MODULES INCLUDED IN PROJECT:
-------------------------------

1)RailwayManagment.java (Main Class containing main method)
2)LoadingandUnloading.java   (Linked list used)
3)SeatReservation.java
4)TrainShedule.java
5)WaitingLounge.java  	      (ArrayList used)
-------------------------------


HOW IT WORKS?

Railway Management class has the menu list to run all the classes, 
-Fisrt you have to find the Train arrival and departure time.
-then you have to reserve the seat (window or non windows by your choice) [for better understanding run the RailwayManagment.java and follow the instruction on the runtime.]
-After the seat reservation if you have any bags lagguage you can store those luggage/bags in the self. that is LoadingandUnloading.java  
-WaitingLounge has been created for the customer where they can wait untill the train arrives.

---------------------------------

Technologies Used:
JAVA 
NETBEANS IDE 8.2  





